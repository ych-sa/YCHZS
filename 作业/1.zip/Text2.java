package com;
import java.io.*;
import java.io.IOException;
public class Text2 {
	public static void main(String[] args)throws IOException{
		InputStreamReader is1=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is1);
		FileWriter fw=new FileWriter("d:\\x.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		String s;
		System.out.print("�������ַ�\n");
		while((s=br.readLine())!=null){
	    	if(s.equals("bye")){
	    		break;
	    	}
	    	else
	    {
	    	bw.write(s);
	    	bw.newLine();
	    }

	    }
		bw.close();
		fw.close();
		br.close();
		is1.close();

		FileInputStream is2=new FileInputStream("d:\\x.txt");
		int hasRead=0;
		System.out.println("Please enter the character what you want to search:");
	    while((hasRead=is2.read())!=-1){
	    	System.out.print((char)hasRead);
	    }
	    is2.close();	
	}
	
}

