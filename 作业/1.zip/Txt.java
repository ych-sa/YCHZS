package com;
import java.io.*;
public class Txt {
	public static void main(String[] args)throws IOException{
	    InputStreamReader isr=new InputStreamReader(System.in);
	    BufferedReader in = new BufferedReader(isr);
	    FileWriter f=new FileWriter("myfile.txt");
	    BufferedWriter bw=new BufferedWriter(f);
	    System.out.print("�������ַ���\n");
	    while(in.readLine()!=null){
	    	if(in.readLine().equals("bye")){
	    		break;
	    	}
	    	else
	    {
	    	bw.write(in.readLine());
	    	bw.newLine();
	    }
	    }
	    bw.close();
	    f.close();
	    in.close();
	    isr.close();
	}			    	
}
