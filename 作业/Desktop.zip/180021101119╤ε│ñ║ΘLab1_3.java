
public class Lab1_3 {
	public static void main(String[] args){
		int ary[]=new int[10];
		for(int i=0;i<ary.length;i++){
			ary[i]=Integer.parseInt(args[i]);}
		int sum=0;
		for(int i=0;i<ary.length;i++){
			sum+=ary[i];}
		System.out.println("�ܺ��ǣ�"+sum);
		double average=(int)sum/10;
		System.out.println("ƽ��ֵ�ǣ�"+average);
		int max=0;
		for(int i=0;i<ary.length;i++){
			if(ary[i]>max){
				max=ary[i];}
		}
		System.out.println("���ֵ�ǣ�"+max);
		int min;
		min=ary[0];
		for(int i=0;i<ary.length;i++){
			if(min>ary[i]){
				min=ary[i];}
		}
		System.out.println("��Сֵ�ǣ�"+min);
	}
}
